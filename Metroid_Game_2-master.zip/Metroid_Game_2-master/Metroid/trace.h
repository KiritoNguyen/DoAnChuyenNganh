#pragma once
#ifndef __TRACE_H_
#define __TRACE_H_
#include <Windows.h>

void trace(const LPWSTR format, ...);

#endif
